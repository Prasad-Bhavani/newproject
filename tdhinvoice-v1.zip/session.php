<?php
if(empty($_SESSION[SID]))
{
	$_SESSION['msg']='Please fill the Login details here';
	$_SESSION['cls']='warning';
	redirect('index');
}
?>