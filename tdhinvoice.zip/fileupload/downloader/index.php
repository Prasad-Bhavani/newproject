<h2>Excel File Downloader</h2>

<center>
	<table border=1 style="width:50%;">
	
		<tr>
			<th>Product</th>
			<th>Quantity</th>
			<th>Price</th>
			<th>Total Price</th>
		</tr>
		
		<tr>
			<td>Motherboard</td>
			<td>10</td>
			<td>5</td>
			<td>50</td>
		</tr>
		
		<tr>
			<td>Processor</td>
			<td>6</td>
			<td>3</td>
			<td>18</td>
		</tr>
		
		<tr>
			<td>Memory</td>
			<td>10</td>
			<td>2.5</td>
			<td>25</td>
		</tr>
		
		<tr>
			<td>Total</td>
			<td>26</td>
			<td>-</td>
			<td>93</td>
		</tr>
	
	</table>
	
<br><br>

<button onclick="window.location='excel-download.php'">Click here to download this data in excel file</button>

</center>