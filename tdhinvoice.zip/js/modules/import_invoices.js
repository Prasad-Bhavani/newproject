app.controller('importInvoicesCtrl', function($scope,$http,blockUI,dataService,ngDialog,NgTableParams,inform,$window,$filter,CONSTANTS)
{
	angular.extend($scope,{
		obj:{}
	});

	angular.extend($scope,{
	});

});